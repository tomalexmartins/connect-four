export const DEFAULT_PLAYER1 = "Player 1";
export const DEFAULT_PLAYER2 = "Player 2";
export const COMPUTER_NAME = "Computer";
